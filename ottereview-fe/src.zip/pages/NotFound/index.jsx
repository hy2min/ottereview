const LandingPage = () => {
  return
}

export default LandingPage
