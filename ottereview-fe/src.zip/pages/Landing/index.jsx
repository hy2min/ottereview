import Button from '../../components/Button'
import { useUserStore } from '../../store/userStore'

const Landing = () => {
  const login = useUserStore((state) => state.login)

  const handleLogin = () => {
    login() // GitHub 연동 없이 로그인 상태 전환
    // 실제로는 여기서 GitHub redirect 처리할 예정
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center text-center space-y-6">
      <h1 className="text-3xl">🦦 Ottereview에 오신 걸 환영합니다!</h1>
      <p className="text-gray-600 text-lg">
        GitHub PR을 리뷰하고 충돌을 해결하는 협업 서비스입니다.
      </p>
      <Button onClick={handleLogin} variant="secondary">
        GitHub로 로그인
      </Button>
    </div>
  )
}

export default Landing
